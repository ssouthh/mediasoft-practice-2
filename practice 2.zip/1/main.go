package main

import (
	"fmt"
)

type Stack struct {
	data []int
}

func (s *Stack) Push(val int) {
	s.data = append(s.data, val)
}

func (s *Stack) Pop() int {
	if len(s.data) == 0 {
		fmt.Println("Стек пуст")
		return -1
	}
	val := s.data[len(s.data)-1]
	s.data = s.data[:len(s.data)-1]
	return val
}

type Queue struct {
	data []int
}

func (q *Queue) Enqueue(val int) {
	q.data = append(q.data, val)
}

func (q *Queue) Dequeue() int {
	if len(q.data) == 0 {
		fmt.Println("Очередь пустая")
		return -1
	}
	val := q.data[0]
	q.data = q.data[1:]
	return val
}

type Node struct {
	value int
	next  *Node
}

type List struct {
	head *Node
}

func (l *List) Add(val int) {
	newNode := &Node{value: val}
	if l.head == nil {
		l.head = newNode
	} else {
		curr := l.head
		for curr.next != nil {
			curr = curr.next
		}
		curr.next = newNode
	}
}

func (l *List) Print() {
	curr := l.head
	for curr != nil {
		fmt.Print(curr.value, " -> ")
		curr = curr.next
	}
	fmt.Println("nil")
}

func main() {
	s := Stack{}
	s.Push(10)
	s.Push(20)
	fmt.Println("Pop из стека:", s.Pop())

	q := Queue{}
	q.Enqueue(1)
	q.Enqueue(2)
	fmt.Println("Dequeue из очереди:", q.Dequeue())

	list := List{}
	list.Add(5)
	list.Add(15)
	list.Print()
}
