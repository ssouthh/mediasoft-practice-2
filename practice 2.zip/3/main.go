package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano())

	rows := 4
	cols := 5
	total := rows * cols

	allNums := rand.Perm(1000)[:total]

	matrix := make([][]int, rows)
	idx := 0
	for i := 0; i < rows; i++ {
		matrix[i] = make([]int, cols)
		for j := 0; j < cols; j++ {
			matrix[i][j] = allNums[idx]
			idx++
		}
	}

	fmt.Println("Матрица:")
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			fmt.Printf("%4d ", matrix[i][j])
		}
		fmt.Println()
	}
}
