package main

import (
	"fmt"
	"strings"
)

func romanToInt(s string) int {
	values := map[byte]int{
		'I': 1,
		'V': 5,
		'X': 10,
		'L': 50,
		'C': 100,
		'D': 500,
		'M': 1000,
	}

	s = strings.ToUpper(s)
	total := 0
	prev := 0

	for i := len(s) - 1; i >= 0; i-- {
		curr := values[s[i]]
		if curr < prev {
			total -= curr
		} else {
			total += curr
		}
		prev = curr
	}

	return total
}

func main() {
	var input string
	fmt.Print("Введите римское число (например, XIV): ")
	fmt.Scanln(&input)

	result := romanToInt(input)
	fmt.Println("Арабское число:", result)
}
